document.getElementById("styleForm")?.addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Your preferences have been submitted! 🎉 Our AI will recommend outfits soon.");
});
